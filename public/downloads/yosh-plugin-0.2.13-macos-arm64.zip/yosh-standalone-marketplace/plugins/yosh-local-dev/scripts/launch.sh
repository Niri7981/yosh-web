#!/bin/sh
set -eu
root="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
if [ -n "${YOSH_STANDALONE_DEV_DATA_DIR:-}" ]; then
  exec "$root/yosh-dev" install-mcp --data-dir "$YOSH_STANDALONE_DEV_DATA_DIR"
fi
exec "$root/yosh-dev" install-mcp
